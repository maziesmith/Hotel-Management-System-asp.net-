﻿using System.Web.UI;

namespace Hotel_Management.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}